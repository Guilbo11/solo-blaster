export interface MonsterEntry {
  id: string;
  name: string;
  description: string;
  potentialProblems: string[];
}

export const MONSTERS: MonsterEntry[] = [
  {
    id: 'mathpanthers',
    name: 'Mathpanthers',
    description:
      'The speed and cunning of a predatory jungle cat combined with the terror and immortality of predatory mathematics. Mathpanthers are drawn by the scent of anomalous logic, such as that given off by rifts in spacetime or interdimensional trespassers.',
    potentialProblems: [
      'Stalks you silently.',
      'Chases you with power, agility, and maybe a few short teleports here and there.',
      'Multiplies into a pack.',
      'Divides its prey.',
      'Continually reforms from any amount of damage unless solved properly.',
      'Tears at you with claws (cut up, sliced wires, etc.)',
      'Pins you to the ground (pinned, frozen in fear, etc.)',
      'Bites your neck, reducing you to your euclidean primitives and causing you to peel back.',
    ],
  },
];
